﻿POSITIVE TEST CASES:



|**Test Case ID: TC001**||Test Designed by: Milena Stojanović||
| :-: | :-: | :- | :- |
|||||
|Test Priority (Low/Medium/High): High||Test Designed date: 12.01.2024.||
|||||
|Test Case Name: Successfully Login and Logout flow|Test Executed by: Milena Stojanović|||
|||||
|Description: Verify that a user can successfully make an appointment ||||
|||||
|No|Test Steps|Test Data|Expected Result|
|1|Launch the website.| |The website is displayed.|
|2|Click on the **side-bar menu**.| |The **side-bar menu** is opened with option Home and Login.|
|3|Click on the **Login** link.| |The user is redirected to the **Login page**.|
|4|Click on the **Username** field.| |Text cursor appears and the field`s outline turns blue.|
|5|In the field **Username** enter valid data.|John Doe|The provided data is displayed in the **Username** field. |
|6|Click on the **Password** field.| |Text cursor appears and the field`s outline turns blue.|
|7|In the field **Password** enter valid data.|ThisIsNotAPassword|The provided data is displayed in the **Password** field. The provided data is displayed as dots.|
|8 |Click on the button **Login**.| |The user is redirected to the **appointment page**.|
|9|Click on the **side-bar** menu.| |The side-bar menu is opened with option Home, History, Profile and Logout.|
|10|Click on the **Logout** link.| |The user is redirected to the **website`s homepage**.|
| | | | |
|||||
|<p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p>||||
|**Test Case ID: TC002**||||
|||||
|Test Priority (Low/Medium/High): High||Test Designed by: Milena Stojanović||
|||||
|Test Case Name: Make appointment using mandatory fields|Test Designed date: 12.01.2024.|||
|||||
|Description: Verify that a user can successfully make an appointment |Test Executed by: Milena Stojanović|||
|||||
|||||
|No|Test Steps|Test Data|Expected Result|
|1|Launch the website.|https://katalon-demo-cura.herokuapp.com/|The website is displayed.|
|2|Click on **Make Appointment** button.| |The user is redirected to the **Login page**.|
|3|Click on the **Username** field.| |Text cursor appears and the field`s outline turns blue.|
|4|In the field **Username** enter valid data.|John Doe|The provided data is displayed in the **Username** field. |
|5|Click on the **Password** field| |Text cursor appears and the field`s outline turns blue.|
|6|In the field **Password** enter valid data.|ThisIsNotAPassword|The provided data is displayed in the **Password** field. The provided data is displayed as a dots.|
|7\. |Click on the button **Login**.| |The user is redirected to the **appointment page**.|
|8|Click on the **Visit Date (Required)** field.| |The cursor appears and the C**alendar** is displayed.|
|9|In the **Calendar** select the current date. |12/01/2024|The date is displayed in the field **Visit Date** and is marked with a blue backgroung in the **Calendar**.|
|10|Click on the button **Book Appointment**.| |The user is redirected to the **summary page** with all booked appointment data.|
|11|Click on the button **Go to Homepage**.| |The user is redirected to the **home page**.|
|||||
|||||
|<p></p><p></p><p></p><p>**Test Case ID: TC003**</p>||||
|||||
|Test Priority (Low/Medium/High): High||Test Designed by: Milena Stojanović||
|||||
|Test Case Name: Make appointment with all data|Test Designed date: 12.01.2024.|||
|||||
|Description: Verify that a user can successfully make appointment filling all fields|Test Executed by: Milena Stojanović|||
|||||
|**Pre-condition:** The user is loged in and it`s on the home page.||||
|No|Test Steps|Test Data|Expected Result|
|1|Click on the field **Facility dropdown menu**.| |**Dropdown menu** is displayed with 3 options.|
|2|**Choose second option.**|HongKong CURA Healthcare Center|**Second option** is selected and displayed.|
|3|Tick the checkbox **Apply for hospital readmission**.| |Checkbox **Apply for hospital readmission** is ticked.|
|4|Select the second option from **HealthCare Program**.|Medicaid radio button|Second option from **Healthcare Program** is selected.|
|5|Click on the **Visit Date (Required)** field.| |The cursor appears and the C**alendar** is displayed.|
|6|Enter valid data using keyboard.|15/01/2024|The date is displayed in the field **Visit Date** and is marked with a blue backgroung in the **Calendar**.|
|7|In the field **Comment** enter minimum one character.|n|In the field **Comment** entered data is displayed.|
|8|Click on the **Book Appointment** button.| |The user is redirected to the **summary page** with all booked appointment data.|
|9|Click on the **side-bar** menu.| |The **side-bar** menu is opened with option Home,History,Profile and Login.|
| | | | |
| | | | |
|||||
|||||
|<p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p>**Test Case ID: TC004**</p>||||
|||||
|Test Priority (Low/Medium/High): High||Test Designed by: Milena Stojanović||
|||||
|Test Case Name: the user can successfully view history of all booked appointments|Test Designed date: 12.01.2024.|||
|||||
|Description: The user will book new appointment and verify that the all appointments is displayed on the History page|Test Executed by: Milena Stojanović|||
|||||
|**Precondition**: The user is on the homepage and has one booked appointment at least.||||
|No|Test Steps|Test Data|Expected Result|
|1|Click on the field **Facility dropdown menu**.| |**Dropdown menu** is displayed with 3 options.|
|2|**Choose the last option.**|Seoul CURA Healthcare Center|**Last option** is selected and displayed.|
|3|Select the last option from **HealthCare Program**.|None|Last option from **Healthcare Program** is selected.|
|4|Click on the **Visit Date (Required)** field.| |The cursor appears and the **Calendar** is displayed.|
|5|Enter valid data using keyboard with fullstops instead slash symbol.|12\.01.2024|The date in the field **Visit Date** is displayed** in default format and is marked with a blue backgroung in the **Calendar**.|
|6\. |In the field **Comment** enter 1000 characters with all symbols.|Entered valid data|In the field **Comment** entered data is displayed.|
|7|Click on the **Book Appointment** button.| |The user is redirected to the **summary page** with all booked appointment data.|
|8|Click on the **side-bar** menu.| |The **side-bar** menu is opened with option Home,History,Profile and Login.|
|10|Click on the **History** link.| |The user is redirected to the **History page** and **a list of  booked** Appointments is displayed.|
|||||
|||||
|<p></p><p></p><p></p><p></p><p></p><p></p><p>**Test Case ID: TC005**</p>||||
|||||
|Test Priority (Low/Medium/High): Medium||Test Designed by: Milena Stojanović||
|||||
|Test Case Name: Inspect the Facebook link|Test Designed date: 12.01.2024.|||
|||||
|Description: |Test Executed by: Milena Stojanović|||
|||||
|Pre-condition: The user is loged in and it`s on the home page.||||
|No|Test Steps|Test Data|Expected Result|
|1|Click on the **Facebook link**.| |The user was redirected to a new tab and t**he Facebook page** was opened.<br>The user remained on the same page.|
|2|** | |** |
|3| | | |
|Comment\* - In a step 1 Test failed. A new tab with Facebook page didn`t open.||||
|||||














NEGATIVE TEST CASES:


<table><tr><th colspan="2" valign="bottom"><b>Test Case ID: NTC001</b></th><th></th><th></th></tr>
<tr><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td colspan="2" valign="top">Test Priority (Low/Medium/High): High</td><td valign="bottom"></td><td valign="bottom">Test Designed by: Milena Stojanović</td></tr>
<tr><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td colspan="3">Test Case Name:  The user can`t login if leave mandatory fields empty</td><td>Test Designed date: 12.01.2024.</td></tr>
<tr><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td colspan="3" valign="bottom">Description: Verify that the user can’t login with the blank mandatory fields </td><td>Test Executed by: Milena Stojanović</td></tr>
<tr><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td>No</td><td>Test Steps</td><td>Test Data</td><td>Expected Result</td></tr>
<tr><td>1</td><td>Launch the website</td><td>https://katalon-demo-cura.herokuapp.com/</td><td>The website is displayed.</td></tr>
<tr><td>2</td><td>Click on the <b>Login</b> button.</td><td> </td><td>The user has stayed on the same page, <b>error message</b> is displayed: ’’Login failed! Please ensure the username and password are valid.’’</td></tr>
<tr><td>3</td><td> </td><td> </td><td> </td></tr>
<tr><td>4</td><td> </td><td> </td><td> </td></tr>
<tr><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td valign="bottom"><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td colspan="2" valign="bottom"><b>Test Case ID: NTC002</b></td><td></td><td></td></tr>
<tr><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td colspan="2" valign="top">Test Priority (Low/Medium/High): High</td><td valign="bottom"></td><td valign="bottom">Test Designed by: Milena Stojanović</td></tr>
<tr><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td colspan="3">Test Case Name: The user can’t login on Make Appointment page with wrong Username</td><td>Test Designed date: 12.01.2024.</td></tr>
<tr><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td colspan="3" valign="bottom">Description:  Verify that the user cannot login with wrong Username</td><td>Test Executed by: Milena Stojanović</td></tr>
<tr><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td>No</td><td>Test Steps</td><td>Test Data</td><td>Expected Result</td></tr>
<tr><td>1</td><td>Launch the website</td><td>https://katalon-demo-cura.herokuapp.com/</td><td>The website is displayed.</td></tr>
<tr><td>2</td><td>Click on the field <b>Password</b>.</td><td> </td><td>Text cursor appears and the field`s outline turns blue.</td></tr>
<tr><td>3</td><td>In the field <b>Password</b> enter valid data.</td><td>ThisIsNotAPassword</td><td>The provided data is displayed in the <b>Password</b> field. The provided data is displayed as a dots.</td></tr>
<tr><td>4</td><td>Click on the <b>Login</b> button</td><td> </td><td>The user has stayed on the same page, <b>error message</b> is displayed: ’’Login failed! Please ensure the username and password are valid.’’</td></tr>
<tr><td>5</td><td> </td><td> </td><td> </td></tr>
<tr><td>6</td><td> </td><td> </td><td> </td></tr>
<tr><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td valign="bottom"><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td colspan="2" valign="bottom"><b>Test Case ID: NTC003</b></td><td></td><td></td></tr>
<tr><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td colspan="2" valign="top">Test Priority (Low/Medium/High): Medium</td><td valign="bottom"></td><td valign="bottom">Test Designed by: Milena Stojanović</td></tr>
<tr><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td colspan="3">Test Case Name: The user can’t login on Make Appointment page with wrong Password</td><td>Test Designed date: 12.01.2024.</td></tr>
<tr><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td colspan="3" valign="bottom">Description:  Verify that the user cannot login with wrong Password</td><td>Test Executed by: Milena Stojanović</td></tr>
<tr><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td>No</td><td>Test Steps</td><td>Test Data</td><td>Expected Result</td></tr>
<tr><td>1</td><td>Launch the website</td><td>https://katalon-demo-cura.herokuapp.com/</td><td>The website is displayed.</td></tr>
<tr><td>2</td><td>Click on the field <b>Username</b>.</td><td> </td><td>Text cursor appears and the field`s outline turns blue.</td></tr>
<tr><td>3</td><td>In the field <b>Username</b> enter valid data.</td><td>John Doe</td><td>The provided data is displayed in the <b>Username</b> field.</td></tr>
<tr><td>4</td><td>Click on the <b>Login</b> button</td><td> </td><td>The user has stayed on the same page, <b>error message</b> is displayed: ’’Login failed! Please ensure the username and password are valid.’’</td></tr>
<tr><td>5</td><td> </td><td> </td><td> </td></tr>
<tr><td>6</td><td> </td><td> </td><td> </td></tr>
<tr><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td valign="bottom"><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p><p></p></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td colspan="2" valign="bottom"><b>Test Case ID: NTC004</b></td><td></td><td></td></tr>
<tr><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td colspan="2" valign="top">Test Priority (Low/Medium/High): Medium</td><td valign="bottom"></td><td valign="bottom">Test Designed by: Milena Stojanović</td></tr>
<tr><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td colspan="3">Test Case Name: user can`t Make Appointment in past (in previous days)</td><td>Test Designed date: 12.01.2024.</td></tr>
<tr><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td colspan="3" valign="top">Description:  </td><td>Test Executed by: Milena Stojanović</td></tr>
<tr><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td><td valign="bottom"></td></tr>
<tr><td>No</td><td>Test Steps</td><td>Test Data</td><td>Expected Result</td></tr>
<tr><td>1</td><td>Launch the website</td><td>https://katalon-demo-cura.herokuapp.com/</td><td>The website is displayed.</td></tr>
<tr><td>2</td><td>Click on <b>Make Appointment</b> button.</td><td> </td><td>The user is redirected to the <b>login page</b>.</td></tr>
<tr><td>3</td><td>Click on the <b>Username</b> field.</td><td> </td><td>Text cursor appears and the field`s outline turns blue.</td></tr>
<tr><td>4</td><td>In the field <b>Username</b> enter valid data.</td><td>John Doe</td><td>The provided data is displayed in the <b>Username</b> field. </td></tr>
<tr><td>5</td><td>Click on the <b>Password</b> field</td><td> </td><td>Text cursor appears and the field`s outline turns blue.</td></tr>
<tr><td>6</td><td>In the field <b>Password</b> enter valid data.</td><td>ThisIsNotAPassword</td><td>The provided data is displayed in the <b>Password</b> field. The provided data is displayed as a dots.</td></tr>
<tr><td>7</td><td>Click on the button <b>Login</b>.</td><td> </td><td>The user is redirected to the <b>appointment page</b>.</td></tr>
<tr><td>8</td><td>Click on the <b>Visit Date (Required)</b> field.</td><td> </td><td>The cursor appears and the calendar is displayed.</td></tr>
<tr><td rowspan="2">9</td><td rowspan="2">In the <b>Calendar</b> select the past date (previous date). </td><td rowspan="2">27/10/2022</td><td rowspan="2" valign="top">The date is displayed in the field <b>Visit Date</b> and is marked with a blue backgroung in the <b>Calendar</b>. <br>The user can`t select the date in past (in previous days,years etc.)</td></tr>
<tr></tr>
<tr><td colspan="4">Comment* - In a step 9 there is a bug. The user can select date in past and Make an Appointment in past.</td></tr>
</table>

